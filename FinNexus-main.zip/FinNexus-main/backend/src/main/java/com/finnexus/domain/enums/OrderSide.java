package com.finnexus.domain.enums;

public enum OrderSide {
    BUY,
    SELL
}
