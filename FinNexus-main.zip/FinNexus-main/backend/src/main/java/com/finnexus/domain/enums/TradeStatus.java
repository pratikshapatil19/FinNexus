package com.finnexus.domain.enums;

public enum TradeStatus {
    OPEN,
    CLOSED
}
