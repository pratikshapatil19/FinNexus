package com.finnexus.service;

import com.finnexus.domain.dto.PnlResponse;

public interface PnlService {
    PnlResponse getPnlSummary();
}
