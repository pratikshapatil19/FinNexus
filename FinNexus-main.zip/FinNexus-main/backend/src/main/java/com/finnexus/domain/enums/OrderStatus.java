package com.finnexus.domain.enums;

public enum OrderStatus {
    PENDING,
    EXECUTED,
    CANCELLED,
    REJECTED
}
