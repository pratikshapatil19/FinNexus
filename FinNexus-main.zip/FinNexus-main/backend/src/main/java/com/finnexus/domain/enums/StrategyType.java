package com.finnexus.domain.enums;

public enum StrategyType {
    MOVING_AVERAGE_CROSSOVER,
    RSI
}
