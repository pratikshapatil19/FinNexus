package com.finnexus.domain.enums;

public enum Timeframe {
    M1,
    M5,
    M15,
    H1,
    D1
}
