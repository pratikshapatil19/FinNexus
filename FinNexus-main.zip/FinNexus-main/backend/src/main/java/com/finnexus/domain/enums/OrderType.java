package com.finnexus.domain.enums;

public enum OrderType {
    MARKET,
    LIMIT
}
